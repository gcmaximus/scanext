console.log('start of program')
aaaaaaaaaaaaaaaaaaaaaaaaaaaaa = window.name
B = aaaaaaaaaaaaaaaaaaaaaaaaaaaaa
console.log('lol')
y = location.hash

// display window name
x = document.getElementById('hi')
x.innerHTML = B

//display location hash
document.querySelector('#bye').outerHTML = y