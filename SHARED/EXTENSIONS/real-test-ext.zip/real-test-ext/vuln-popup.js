x = window.name

document.write(x)

y = location.hash

document.getElementById('abc').innerHTML = y