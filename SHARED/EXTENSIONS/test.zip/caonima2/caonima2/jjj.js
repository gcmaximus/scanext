x = window.name
document.write(x)

y = location.href
document.getElementById('hello').innerHTML = y