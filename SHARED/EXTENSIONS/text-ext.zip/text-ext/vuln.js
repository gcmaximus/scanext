x = window.name

document.write(x)

y = location.href

document.getElementById('abc').innerHTML = y