x = window.name
document.write(x)