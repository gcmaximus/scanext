x = window.name
$('abc').attr("href", window.name)