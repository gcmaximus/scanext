console.log('start')
document.write(location.hash)
console.log('end')