w = location.href

$('bye').prepend(w)



x = window.name

document.getElementById('abc').innerHTML = x


// y = location.href

// $('hello').append(`<div>${y}</div>`)

// z = window.name

// document.getElementById('xyz').outerHTML = z

