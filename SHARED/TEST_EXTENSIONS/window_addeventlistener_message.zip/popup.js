window.addEventListener('DOMContentLoaded', function () {
    const replaceButton = document.getElementById('replaceButton');
    replaceButton.addEventListener('click', function () {
        const messageInput = document.getElementById(
            'messageInput');
        const message = messageInput.value;

        window.addEventListener('message', function (event) {
            const h1 = document.querySelector('h1');
            if (h1) {
                h1.textContent = event.data;
            }
        });

        chrome.tabs.query({
            active: true,
            currentWindow: true
        }, function (tabs) {
            chrome.scripting.executeScript({
                target: {
                    tabId: tabs[0].id
                },
                function: sendMessageToWindow,
                args: [message]
            });
        });
    });
});

function sendMessageToWindow(message) {
    window.addEventListener("message", function (event) {
        if (event.data && event.data.message) {
            replaceTitle(event.data.message);
            const h1 = document.querySelector("h1");
            if (h1) {
                h1.innerHTML = message;
            }
        }
    });

}
