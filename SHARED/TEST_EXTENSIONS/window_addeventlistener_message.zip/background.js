// Empty background script as it's not required for this functionality.
