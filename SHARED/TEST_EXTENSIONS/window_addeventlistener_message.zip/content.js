window.addEventListener("message", function(event) {
    if (event.data && event.data.message) {
      replaceTitle(event.data.message);
    }
  });
  
  function replaceTitle(message) {
    const h1 = document.querySelector("h1");
    if (h1) {
      h1.innerHTML = message;
    }
  }
  