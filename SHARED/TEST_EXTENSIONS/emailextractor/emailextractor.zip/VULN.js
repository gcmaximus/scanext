var abc = window.name

var vuln = document.getElementById('vuln')

vuln.innerHTML = abc